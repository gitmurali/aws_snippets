def lambda_handler(event, context):
    """
    A simple AWS Lambda function that returns a greeting.
    """
    return {
        'statusCode': 200,
        'body': 'Hello, World!'
    }
